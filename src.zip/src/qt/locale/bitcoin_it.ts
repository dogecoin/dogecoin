<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>AddPeerDialog</name>
    <message>
        <source>Add Peer</source>
        <translation>Aggiungi Peer</translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation>Inserisci i dettagli del peer.</translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation>Fai attenzione! Non fidarti ciecamente di chi ti chiede di aggiungere il suo nodo.</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation>Aggiungi l&apos;indirizzo del peer</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation>Aggiungi la porta del peer</translation>
    </message>
    <message>
        <source>Add!</source>
        <translation>Aggiungi!</translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation>Inserici un indirizzo.</translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation>Inserisci un indirizzo valido per il peer.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Fare clic con il tasto destro del mouse per modificare l&apos;indirizzo o l&apos;etichetta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crea un nuovo indirizzo</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nuovo</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia negli appunti l&apos;indirizzo attualmente selezionato</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C&amp;hiudi</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Rimuovi dalla lista l&apos;indirizzo attualmente selezionato</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Esporta su file i dati contenuti nella tabella corrente</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Esporta</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Elimina</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Scegli l&apos;indirizzo a cui inviare Dogecoin</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Scegli l&apos;indirizzo con cui ricevere Dogecoin</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>Sc&amp;egli</translation>
    </message>
    <message>
        <source>Such sending addresses</source>
        <translation>Indirizzi d&apos;invio</translation>
    </message>
    <message>
        <source>Much receiving addresses</source>
        <translation>Indirizzi di ricezione</translation>
    </message>
    <message>
        <source>These are your Dogecoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Questo è un elenco di indirizzi Dogecoin a cui puoi inviare pagamenti. Controlla sempre l&apos;importo e l&apos;indirizzo del beneficiario prima di inviare Dogecoin.</translation>
    </message>
    <message>
        <source>These are your Dogecoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Questi sono i tuoi indirizzi Dogecoin che puoi usare per ricevere pagamenti. Si raccomanda di generare un nuovo indirizzo per ogni transazione.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copia l&apos;indirizzo</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Copia &amp;l&apos;etichetta</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Esporta la Lista degli Indirizzi</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Esportazione Fallita</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Si è verificato un errore tentando di salvare la lista degli indirizzi su %1. Si prega di riprovare.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Finestra password</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Inserisci la password</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nuova password</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Ripeti la nuova password</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Inserisci la nuova password per il portafoglio.&lt;br/&gt;Si consiglia di utilizzare &lt;b&gt;almeno dieci caratteri casuali&lt;/b&gt; oppure &lt;b&gt;otto o più parole&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Cripta il portafoglio</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Questa operazione necessita della password per sbloccare il portafoglio.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Sblocca il portafoglio</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Quest&apos;operazione necessita della password per decrittare il portafoglio,</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Decripta il portafoglio</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Cambia la password</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>Inserisci la vecchia e la nuova password per il portafoglio.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Conferma la criptatura del portafoglio</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR DOGECOINS&lt;/b&gt;!</source>
        <translation>Attenzione: se cripti il portafoglio e perdi la password, &lt;b&gt;PERDERAI TUTTI I TUOI DOGECOIN&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Sei sicuro di voler criptare il portafoglio?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Portafoglio criptato</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>IMPORTANTE: qualsiasi backup del file portafoglio effettuato in precedenza dovrà essere sostituito con il file del portafoglio criptato appena generato. Per ragioni di sicurezza, i precedenti backup del file del portafoglio non criptato diventeranno inservibili non appena si inizierà ad utilizzare il nuovo portafoglio criptato.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Il processo di crittografia del tuo portafogli è fallito</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Crittaggio fallito a causa di un errore interno. Il portafoglio non è stato crittato.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Le password non corrispondono.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Sblocco del portafoglio fallito</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La password inserita per decrittare il tuo portafoglio è errata</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Decrittazione del portafoglio fallita.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>La password di accesso al portafoglio è stata cambiata con successo.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Attenzione: è attivo il tasto blocco maiuscole !</translation>
    </message>
    <message>
        <source>%1 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your dogecoins from being stolen by malware infecting your computer.</source>
        <translation>%1 si chiuderá per completare il processo di criptatura. Ricordati che criptare il portafoglio potrebbe non proteggere i tuoi dogecoin nel caso in cui il tuo computer sia infetto da malware.</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP/Netmask</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Bannato fino a</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Firma &amp;messaggio...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Sincronizzazione con la rete in corso...</translation>
    </message>
    <message>
        <source>&amp;Wow</source>
        <translation>&amp;Wow</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nodo</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Mostra la panoramica del portafoglio</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transazioni</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Mostra la cronologia delle transazioni</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Chiudi applicazione</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Informazioni su %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Mostra informazioni su %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Informazioni su &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Mostra le informazioni su Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opzioni...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Modifica le opzioni di configurazione per %1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Cripta il portafoglio...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Backup portafoglio...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Cambia password...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Apri &amp;URI...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Re-indicizzazione blocchi su disco...</translation>
    </message>
    <message>
        <source>Send coins to a Dogecoin address</source>
        <translation>Invia monete ad un indirizzo Dogecoin</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Esegui il backup del portafoglio in un&apos;altra posizione</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Cambia la password utilizzata per criptare il portafoglio</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>Finestra di &amp;debug</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Apri la console di debugging e diagnostica</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifica messaggio...</translation>
    </message>
    <message>
        <source>Dogecoin</source>
        <translation>Dogecoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Portafoglio</translation>
    </message>
    <message>
        <source>&amp;Such Send</source>
        <translation>&amp;Invia</translation>
    </message>
    <message>
        <source>&amp;Much Receive</source>
        <translation>&amp;Ricevi</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Mostra / Nascondi</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Mostra o nascondi la Finestra principale</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Cripta le chiavi private del tuo portafoglio</translation>
    </message>
    <message>
        <source>Sign messages with your Dogecoin addresses to prove you own them</source>
        <translation>Firma i messaggi con il tuo indirizzo Dogecoin per dimostrarne il possesso</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Dogecoin addresses</source>
        <translation>Verifica i messaggi per accertare che siano stati firmati con gli indirizzi Dogecoin specificati</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Impostazioni</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aiuto</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Barra degli strumenti</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and dogecoin: URIs)</source>
        <translation>Richiedi pagamenti (genera codici QR e dogecoin: URI)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Mostra la lista degli indirizzi di invio utilizzati</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Mostra la lista degli indirizzi di ricezione utilizzati</translation>
    </message>
    <message>
        <source>Open a dogecoin: URI or payment request</source>
        <translation>Apri un URI o una richiesta di pagamento</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Opzioni della riga di &amp;comando</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Dogecoin network</source>
        <translation>
            <numerusform>%n connessione attiva alla rete Dogecoin</numerusform>
            <numerusform>%n connessioni attive alla rete Dogecoin</numerusform>
        </translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Indicizzando i blocchi su disco...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Processando i blocchi su disco...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation>
            <numerusform>Elaborato %n blocco dello storico transazioni.</numerusform>
            <numerusform>Elaborati %n blocchi dello storico transazioni.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>Indietro di %1</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>L&apos;ultimo blocco ricevuto è stato generato %1 fa.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Le transazioni effettuate successivamente non sono ancora visibili.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Aggiornato</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Dogecoin command-line options</source>
        <translation>Mostra il messaggio di aiuto di %1 per ottenere una lista di opzioni di comando per Dogecoin </translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1 client</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>In aggiornamento...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Data: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Quantità: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Tipo: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Etichetta: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Indirizzo: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transazione inviata</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Transazione ricevuta</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Il portafoglio è &lt;b&gt;criptato&lt;/b&gt; ed attualmente &lt;b&gt;sbloccato&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Il portafoglio è &lt;b&gt;criptato&lt;/b&gt; ed attualmente &lt;b&gt;bloccato&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Print paper wallets</source>
        <translation>&amp;Stampa paper wallets</translation>
    </message>
    <message>
        <source>Print paper wallets</source>
        <translation>Stampa paper wallets</translation>
    </message>
    <message>
        <source>&amp;Such sending addresses...</source>
        <translation>Indirizzi di invio</translation>
    </message>
    <message>
        <source>&amp;Much receiving addresses...</source>
        <translation>&amp;Indirizzi di ricezione</translation>
    </message>
    <message>
        <source>&amp;Import Private Key...</source>
        <translation>&amp;Importa chiave privata</translation>
    </message>
    <message>
        <source>Import a Dogecoin private key</source>
        <translation>Importa una chiave privata</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Clicca per disabilitare attività di rete.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>Attività di rete disabilitata.</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>Clicca per riabilitare attività di rete.</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>Sincronizzazione Headers (%1%)...</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>Connessione ai peers in corso...</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation>La creazione della chiave HD è &lt;b&gt;abilitata&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>La creazione della chiave HD è &lt;b&gt;disabilitata&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Runaway exception</source>
        <translation>Eccezione runaway</translation>
    </message>
    <message>
        <source>A fatal error occurred. Dogecoin can no longer continue safely and will quit.</source>
        <translation>Si è verificato un errore critico. Dogecoin non può più continuare ad operare in sicurezza e verrà chiuso.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Selezione Input</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantità:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Importo:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Commissione:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Polvere (dust):</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Dopo Commissione:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Resto:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(de)seleziona tutto</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Modalità Albero</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Modalità Lista</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Ricevuto con l&apos;etichetta</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Ricevuto con l&apos;indirizzo</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Conferme</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copia indirizzo</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia etichetta</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Copia l&apos;ID transazione</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Bloccare non spesi</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Sbloccare non spesi</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Copia quantità</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Copia commissione</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Copia dopo commissione</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Copia byte</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Copia polvere</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Copia resto</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 bloccato)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>sì</translation>
    </message>
    <message>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation>Questa etichetta diventa rossa se uno qualsiasi dei destinatari riceve un importo inferiore alla soglia minima per la movimentazione della valuta (dust threshold).</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>cambio da %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(resto)</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu per input.</source>
        <translation>Può variare di +/- %1 koinu per input.</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Modifica l&apos;indirizzo</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etichetta</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>L&apos;etichetta associata con questa voce dell&apos;elenco degli indirizzi</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>L&apos;indirizzo associato con questa voce dell&apos;elenco degli indirizzi. Può essere modificato solo per gli indirizzi d&apos;invio.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Indirizzo</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nuovo indirizzo di ricezione</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nuovo indirizzo d&apos;invio</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Modifica indirizzo di ricezione</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Modifica indirizzo d&apos;invio</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Dogecoin address.</source>
        <translation>L&apos;indirizzo inserito &quot;%1&quot; non è un indirizzo Dogecoin valido.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>L&apos;indirizzo inserito &quot;%1&quot; è già in rubrica.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Impossibile sbloccare il portafoglio.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Generazione della nuova chiave non riuscita.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Sarà creata una nuova cartella dati.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>nome</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Cartella già esistente. Aggiungi %1 se intendi creare qui una nuova cartella.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Il percorso è già esistente e non è una cartella.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Impossibile creare una cartella dati qui.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>versione</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Informazioni %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Opzioni della riga di comando</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Utilizzo:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>opzioni della riga di comando</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>Opzioni interfaccia:</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>Seleziona la directory dei dati all&apos;avvio (default: %u)</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Imposta la lingua, ad esempio &quot;it_IT&quot; (default: locale di sistema)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Avvia ridotto a icona</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Imposta un certificato SSL root per le richieste di pagamento (default: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>Mostra schermata iniziale all&apos;avvio (default: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>Reimposta tutti i campi dell&apos;interfaccia grafica</translation>
    </message>
</context>
<context>
    <name>ImportKeysDialog</name>
    <message>
        <source>Import Private Key</source>
        <translation>Importa Chiave Privata</translation>
    </message>
    <message>
        <source>&amp;Import Private Key</source>
        <translation>&amp;Importa Chiave Privata</translation>
    </message>
    <message>
        <source>Private Key:</source>
        <translation>Chiave Privata:</translation>
    </message>
    <message>
        <source>Private key to import into your wallet</source>
        <translation>Chiave privata da importare nel tuo portafoglio.</translation>
    </message>
    <message>
        <source>Label for this private key in your wallet</source>
        <translation>Etichetta della chiave privata nel tuo portofoglio.</translation>
    </message>
    <message>
        <source>Label (optional):</source>
        <translation>Etichetta (opzionale):</translation>
    </message>
    <message>
        <source>Rescan</source>
        <translation>Ripeti scansione</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>Resetta</translation>
    </message>
    <message>
        <source>&amp;Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>Invalid private key; please check and try again!</source>
        <translation>Chiave privata non valida; controlla e riprova!</translation>
    </message>
    <message>
        <source>Invalid address generated from private key; please check and try again!</source>
        <translation>L&apos;indirizzo generato dalla chiave privata non è valido; controlla e riprova!</translation>
    </message>
    <message>
        <source>Failed to add private key.</source>
        <translation>Impossible importare la chiave privata.</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Ripetizione scansione...</translation>
    </message>
    <message>
        <source>Reset this form.</source>
        <translation>Resetta questa form.</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Benvenuto</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Benvenuto su %1.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>Dato che questa è la prima volta che il programma viene lanciato, puoi scegliere dove %1 salverà i suoi dati.</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Dogecoin block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>%1 scaricherà e salverà una copia della blockchain di Dogecoin. Saranno salvati almeno %2GB di dati in questa directory e continueranno ad aumentare col tempo. Anche il portafoglio verrà salvato in questa directory.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Usa la cartella dati predefinita</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Usa una cartella dati personalizzata:</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; cannot be created.</source>
        <translation>Errore: La cartella dati &quot;%1&quot; specificata non può essere creata.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation>
            <numerusform>GB di spazio libero disponibile</numerusform>
            <numerusform>%n GB di spazio disponibile</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation>
            <numerusform>(di %nGB richiesti)</numerusform>
            <numerusform>(%n GB richiesti)</numerusform>
        </translation>
    </message>
    <message>
        <source>Choose data directory</source>
        <translation>Scegli la cartella dati</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation>Numero di blocchi mancanti</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>Sconosciuto...</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Ora del blocco più recente</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Nascondi</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet&apos;s balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the dogecoin network, as detailed below.</source>
        <translation>Le transazioni recenti potrebbero non essere ancora visibili, quindi il saldo totale del tuo portafoglio potrebbe non essere corretto. Il saldo risulterà corretto quando il tuo portafoglio avrà completato la sincronizzazione con la rete dogecoin, come indicato più sotto.</translation>
    </message>
    <message>
        <source>Attempting to spend dogecoins that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation>Il tentativo di spendere dogecoin legati a transazioni non ancora visualizzate non verrà accettato dalla rete</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation>Progresso orario</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>calcolando...</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation>Tempo stimato al completamento della sincronizzazione</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1)...</source>
        <translation>Sconosciuto. Sincronizzazione headers (%1)...</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Apri URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Apri una richiesta di pagamento da URI o file</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Seleziona il file di richiesta di pagamento</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Seleziona il file di richiesta di pagamento da aprire</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Principale</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>Avvia automaticamente %1 una volta effettuato l&apos;accesso al sistema.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>&amp;Apri %1 automaticamente all&apos;avvio del sistema</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Dimensione della cache del &amp;database</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Numero di thread di &amp;verifica degli script </translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Accetta connessioni provenienti dall&apos;esterno</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Permetti connessioni in ingresso</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>Indirizzo IP del proxy (ad es. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>Riduci ad icona invece di uscire dall&apos;applicazione quando la finestra viene chiusa. Attivando questa opzione l&apos;applicazione terminerà solo dopo aver selezionato Esci dal menu File.</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>URL di servizi esterni (ad es. un block explorer) che appaiono nella tabella delle transazioni come voci nel menu contestuale. &quot;%s&quot; nell&apos;URL è sostituito dall&apos;hash della transazione.
Per specificare più URL separarli con una barra verticale &quot;|&quot;.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>URL transazioni per servizi esterni</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Opzioni della riga di comando attive che sostituiscono i settaggi sopra elencati:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Reimposta tutte le opzioni del client allo stato predefinito.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Ripristina Opzioni</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>Rete</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = automatico, &lt;0 = lascia questo numero di core liberi)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Port&amp;afoglio</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Esperti</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Abilita le funzionalità di coin &amp;control</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Disabilitando l&apos;uso di resti non confermati, il resto di una transazione non potrà essere speso fino a quando non avrà ottenuto almeno una conferma. Questa impostazione influisce inoltre sul calcolo del saldo.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Spendi resti non confermati</translation>
    </message>
    <message>
        <source>Automatically open the Dogecoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Apri automaticamente la porta del client Dogecoin sul router. Il protocollo UPnP deve essere supportato da parte del router ed attivo.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Mappa le porte tramite &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Dogecoin network through a SOCKS5 proxy.</source>
        <translation>Connessione alla rete Dogecoin attraverso un proxy SOCKS5.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Connessione attraverso proxy SOCKS5 (proxy predefinito):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP del proxy:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Porta:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Porta del proxy (ad es. 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>Utilizzata per connettersi attraverso:</translation>
    </message>
    <message>
        <source>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>Mostra se il proxy SOCKS5 fornito viene utilizzato per raggiungere i peers attraverso questo tipo di rete.</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Dogecoin network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>Connessione alla rete Dogecoin attraverso un proxy SOCKS5 separato per Tor.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</source>
        <translation>Usa un proxy SOCKS5 separato per la connessione ai peers attraverso Tor:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Finestra</translation>
    </message>
    <message>
        <source>&amp;Hide the icon from the system tray.</source>
        <translation>Nascondi l&apos;icona nella barra delle applicazioni.</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>Nascondi l&apos;icona nella barra applicazioni</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Mostra solo nella tray bar quando si riduce ad icona.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimizza nella tray bar anziché nella barra delle applicazioni</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimizza alla chiusura</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Mostra</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Lingua interfaccia utente:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>Qui puoi scegliere la lingua dell&apos;interfaccia utente. La scelta avrà effetto dopo il riavvio di %1.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unità di misura con cui visualizzare gli importi:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Scegli l&apos;unità di suddivisione predefinita da utilizzare per l&apos;interfaccia e per l&apos;invio di dogecoin.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Specifica se le funzionalita di coin control saranno visualizzate.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>default</source>
        <translation>predefinito</translation>
    </message>
    <message>
        <source>none</source>
        <translation>nessuno</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Conferma ripristino opzioni</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>È necessario un riavvio del client per applicare le modifiche.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Il client sarà arrestato. Si desidera procedere?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Questa modifica richiede un riavvio del client.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>L&apos;indirizzo proxy che hai fornito non è valido.</translation>
    </message>
    <message>
        <source>Disables some advanced features but all blocks will still be fully validated. Reverting this setting requires re-downloading the entire blockchain. Actual disk usage may be somewhat higher.</source>
        <translation>Disabilita alcune funzionalitá avanzate, ma tutti i blocchi risulteranno ancora convalidati. La modifica di questa opzione richiede una nuova sincronizzazione dell&apos;intera blockchain con la rete.</translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation>Riduci lo spazio per lo storage dei &amp;blocchi a</translation>
    </message>
    <message>
        <source>GB</source>
        <translation>GB</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation>La modifica di questa opzione richiede una nuova sincronizzazione dell&apos;intera blockchain con la rete.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Dogecoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Le informazioni visualizzate potrebbero non essere aggiornate. Il portafoglio si sincronizza automaticamente con la rete Dogecoin una volta stabilita una connessione, ma questo processo non è ancora stato completato.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Sola lettura:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Disponibile:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Il tuo saldo spendibile attuale</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>In attesa:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Totale delle transazioni in corso di conferma e che non sono ancora conteggiate nel saldo disponibile</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Immaturo:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Importo generato dal mining e non ancora maturato</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Totale:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Il tuo saldo totale attuale</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Il tuo saldo attuale negli indirizzi di sola lettura</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Spendibile:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Transazioni recenti</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Transazioni non confermate su indirizzi di sola lettura</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Importo generato dal mining su indirizzi di sola lettura e non ancora maturato</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Saldo totale disponibile negli indirizzi di sola lettura</translation>
    </message>
    <message>
        <source>Helpful tip of the day:</source>
        <translation>Suggerimento del giorno:</translation>
    </message>
    <message>
        <source>Tip</source>
        <translation>Suggerimento</translation>
    </message>
    <message>
        <source>Encrypt your wallet with a strong passphrase for maximum security</source>
        <translation>Cripta il portafoglio con una password complessa per maggior sicurezza</translation>
    </message>
    <message>
        <source>Backup your private key to recover your coins, using &apos;File&apos; &gt; &apos;Backup Wallet&apos;</source>
        <translation>Fai un backup delle tue chiavi private usando il menu &apos;File&apos; &gt; &apos;Backup Portafoglio&apos; </translation>
    </message>
    <message>
        <source>Always do your own research before using an external cryptocurrency service</source>
        <translation>Fai le dovute ricerche prima di utilizzare qualsiasi servizio criptovalute.</translation>
    </message>
    <message>
        <source>Services that claim to double your dogecoins are always ponzi schemes</source>
        <translation>Tutti i servizi che promettono di moltiplicare i tuoi Dogecoin sono delle truffe.</translation>
    </message>
    <message>
        <source>Never share your wallet.dat file with anyone</source>
        <translation>Non condividere mai con nessuno il tuo file wallet.dat.</translation>
    </message>
    <message>
        <source>For advanced operations, use the console in &apos;Help&apos; -&gt; &apos;Debug Window&apos;</source>
        <translation>Per accedere alle funzionalitá avanzate usa la console tramite il menu &apos;Aiuto&apos; -&gt; &apos;Finestra di debug&apos;</translation>
    </message>
    <message>
        <source>Make sure to keep your wallet software updated</source>
        <translation>Ricordati di aggiornare il tuo portafoglio.</translation>
    </message>
    <message>
        <source>Never share your private key with anyone</source>
        <translation>Non condividere mai con nessuno la tua chiave privata.</translation>
    </message>
    <message>
        <source>Who owns the private keys, owns the coins</source>
        <translation>Chiunque abbia accesso alla chiave privata ha il controllo totale sul portafoglio.</translation>
    </message>
    <message>
        <source>To see ongoing development and contribute, check out the Dogecoin Core repository on GitHub</source>
        <translation>Per essere aggiornato sullo sviluppo di Dogecoin e contribuire, segui il repository su GitHub!</translation>
    </message>
</context>
<context>
    <name>PaperWalletDialog</name>
    <message>
        <source>Print Your Paper Wallets</source>
        <translation>Stampa i tuoi Paper Wallets</translation>
    </message>
    <message>
        <source>Very New Address</source>
        <translation>Nuovo Indirizzo</translation>
    </message>
    <message>
        <source>So Print</source>
        <translation>Stampa</translation>
    </message>
    <message>
        <source>Many Wallets?</source>
        <translation>Portafogli</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public Key:</source>
        <translation>Chiave Pubblica:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Warning: Network Activity Detected</source>
        <translation>Attenzione: rilevata attività di rete</translation>
    </message>
    <message>
        <source>It is recommended to disconnect from the internet before printing paper wallets. Even though paper wallets are generated on your local computer, it is still possible to unknowingly have malware that transmits your screen to a remote location. It is also recommended to print to a local printer vs a network printer since that network traffic can be monitored. Some advanced printers also store copies of each printed document. Proceed with caution relative to the amount of value you plan to store on each address.</source>
        <translation>È preferibile disconnettersi dalla rete internet prima di stampare un paper wallet. Anche se i paper wallets sono generati localmente nel tuo computer, è possibile che un malware nascosto nel tuo computer trasmetta remotamente immagini del tuo schermo. Si raccomanda di stampare il portafoglio utilizzando una stampante connessa direttamente al computer; il traffico di una rete locale può essere monitorato. Alcune stampanti più avanzate possono anche salvare localmente copie dei documenti stampati. Fai inoltre attenzione a limitare l&apos;importo contenuto in un singolo indirizzo.</translation>
    </message>
    <message>
        <source>Error encoding Address into QR Code.</source>
        <translation>Errore nella codifica dell&apos;indirizzo nel codice QR.</translation>
    </message>
    <message>
        <source>Error encoding private key into QR Code.</source>
        <translation>Errore nella codifica della chiave privata nel codice QR.</translation>
    </message>
    <message>
        <source>Printing Error</source>
        <translation>Errore di stampa</translation>
    </message>
    <message>
        <source>failed to open file, is it writable?</source>
        <translation>impossibile aprire il file, controlla i permessi.</translation>
    </message>
    <message>
        <source>Load Paper Wallets</source>
        <translation>Carica Paper Wallets</translation>
    </message>
    <message>
        <source>The paper wallet printing process has begun.&lt;br/&gt;Please wait for the wallets to print completely and verify that everything printed correctly.&lt;br/&gt;Check for misalignments, ink bleeding, smears, or anything else that could make the private keys unreadable.&lt;br/&gt;Now, enter the number of DOGE you wish to send to each wallet:</source>
        <translation>Il processo di stampa del paper wallet è iniziato.&lt;br/&gt;Attendi che la stampa sia completa; successivamente, verifica che non ci siano stati errori di stampa.&lt;br/&gt;Controlla che non ci siano distorsioni, macchie, o problemi che potrebbero rendere il paper wallet illegibile.&lt;br/&gt;Ora inserisci la quantità di DOGE che vuoi inviare all&apos;indirizzo di ciascun portafoglio:</translation>
    </message>
    <message>
        <source>Paper wallet %1</source>
        <translation>Paper wallet %1</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to Paper Wallet &lt;span style=&apos;font-family: monospace;&apos;&gt;%2&lt;/span&gt;</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; al Paper Wallet &lt;span style=&apos;font-family: monospace;&apos;&gt;%2&lt;/span&gt;</translation>
    </message>
    <message>
        <source>Send Coins</source>
        <translation>Invia Dogecoin</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>L&apos;indirizzo del destinatario non è valido, controlla di nuovo.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0</source>
        <translation>L&apos;importo da inviare deve essere superiore a 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Saldo insufficiente</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the transaction fee is included</source>
        <translation>Il totale, inclusa la commissione di transazione, è superiore al saldo disponibile.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Indirizzo già inserito. Puoi inviare Dogecoin allo stesso indirizzo solo una volta nella stessa operazione.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Creazione della transazione fallita!</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Sei sicuto di voler inviare?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation> aggiunti per la commissione di transazione</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>Importo Totale %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>o</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Conferma l&apos;invio</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>La transazione è stata rifiutata! Questo potrebbe accadere nel caso in cui alcuni dei tuoi fondi siano stati giá spesi, per esempio se hai usato una copia del file wallet.dat altrove e i fondi sono stati spesi nella copia ma non ancora registrati come spesi in questa installazione.</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation>Errore di richiesta di pagamento</translation>
    </message>
    <message>
        <source>Cannot start dogecoin: click-to-pay handler</source>
        <translation>Impossibile avviare dogecoin: gestore click-to-pay</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation>Gestione URI</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>URL di recupero della Richiesta di pagamento non valido: %1</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Indirizzo di pagamento non valido %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Dogecoin address or malformed URI parameters.</source>
        <translation>Impossibile interpretare l&apos;URI! I parametri dell&apos;URI o l&apos;indirizzo Dogecoin potrebbero non essere corretti.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Gestione del file di richiesta del pagamento</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>Impossibile leggere il file della richiesta di pagamento! Il file della richiesta di pagamento potrebbe non essere valido</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Richiesta di pagamento respinta</translation>
    </message>
    <message>
        <source>Payment request network doesn&apos;t match client network.</source>
        <translation>La rete della richiesta di pagamento non corrisponde alla rete del client.</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Richiesta di pagamento scaduta.</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>La richiesta di pagamento non è stata inizializzata.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Le richieste di pagamento non verificate verso script di pagamento personalizzati non sono supportate.</translation>
    </message>
    <message>
        <source>Invalid payment request.</source>
        <translation>Richiesta di pagamento invalida</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Rimborso da %1</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>La richiesta di pagamento %1 è troppo grande (%2 bytes, consentiti %3 bytes)</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Errore di comunicazione con %1: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>La richiesta di pagamento non può essere processata!</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Pagamento riconosciuto</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Risposta non valida dal server %1</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Errore di rete</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (below discard threshold).</source>
        <translation>Il pagamento richiesto di %1 è troppo basso.</translation>
    </message>
    <message>
        <source>BIP70 payment requests are deprecated and disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation>Le richieste di pagamento BIP70 sono obsolete e disabilitate per impostazione predefinita. Riavvia con -enable-bip70 se hai assolutamente bisogno di utilizzare questa funzionalità.

        Utilizza questa funzionalità con estrema cautela.
        </translation>
    </message>
    <message>
        <source>Payment request file handling is disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation>La gestione dei file per le richieste di pagamento è disabilitata per impostazione predefinita. Riavvia con -enable-bip70 se hai assolutamente bisogno di utilizzare questa funzionalità.

        Utilizza questa funzionalità con estrema cautela.  
        </translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>User Agent</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>Nodo/Servizio</translation>
    </message>
    <message>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <source>NodeId</source>
        <translation>Id Nodo</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation>Bytes Inviati</translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation>Bytes Ricevuti</translation>
    </message>
</context>
<context>
    <name>PeerTools</name>
    <message>
        <source>Error: Peer-to-peer functionality missing or disabled</source>
        <translation>Errore: funzionalitá peer-to-peer mancante o disabilitata.</translation>
    </message>
    <message>
        <source>Attempted to one try node.</source>
        <translation>Tentativo singolo di connessione al nodo.</translation>
    </message>
    <message>
        <source>Node not found in connected nodes</source>
        <translation>Nodo non trovato tra i nodi connessi</translation>
    </message>
    <message>
        <source>Disconnected the node: </source>
        <translation>Nodo disconnesso:</translation>
    </message>
    <message>
        <source>Returned OK.</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Error: Node address is invalid</source>
        <translation>Errore: L&apos;indirizzo del nodo non è valido</translation>
    </message>
    <message>
        <source>Error: Unable to add node</source>
        <translation>Errore: Impossibile aggiungere il nodo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <source>Enter a Dogecoin address (e.g. %1)</source>
        <translation>Inserisci un indirizzo Dogecoin (ad es. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation>
            <numerusform>%n secondo</numerusform>
            <numerusform>%n secondi</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation>
            <numerusform>%n minuto</numerusform>
            <numerusform>%n minuti</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation>
            <numerusform>%n ora</numerusform>
            <numerusform>%n ore</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation>
            <numerusform>%n giorno</numerusform>
            <numerusform>%n giorni</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation>
            <numerusform>%n settimana</numerusform>
            <numerusform>%n settimane</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 e %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation>
            <numerusform>%n anno</numerusform>
            <numerusform>%n anni</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 kB</source>
        <translation>%1 kB</translation>
    </message>
    <message>
        <source>%1 didn&apos;t yet exit safely...</source>
        <translation>%1 non si è ancora chiuso...</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error: %1</source>
        <translation>Errore: %1</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>Errore: la cartella dati &quot;%1&quot; non esiste.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation>Errore: Impossibile processare il file: %1. Utilizzare unicamente la sintassi key=value.</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Salva immagine</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Copia immagine</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Salva codice QR</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>Immagine PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Versione client</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informazioni</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Finestra di debug</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Versione BerkeleyDB in uso</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>Directory Dati</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Ora di avvio</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Rete</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Numero di connessioni</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Block chain</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Numero attuale di blocchi</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Memory Pool</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Numero attuale di transazioni</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Utilizzo memoria</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Ricevuto</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Inviato</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Peer</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Peers bannati</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Seleziona un peer per visualizzare informazioni più dettagliate.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>Whitelisted/sicuri</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Direzione</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Blocco di partenza</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Headers sincronizzati</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Blocchi sincronizzati</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>User Agent</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Apri il file log del debug di %1 dalla cartella dati attuale. Può richiedere alcuni secondi per file di log di grandi dimensioni.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Riduci dimensioni font.</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Aumenta dimensioni font</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Servizi</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Punteggio di Ban</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Tempo di Connessione</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Ultimo Invio</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Ultima Ricezione</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Tempo di Ping</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>La durata di un ping attualmente in corso.</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Attesa ping</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Scarto Temporale</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Ora del blocco più recente</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Apri</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Console</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Traffico di Rete</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totali</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Entrata:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Uscita:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>File log del Debug</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Cancella console</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;ora</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;giorno</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;settimana</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;anno</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation>&amp;Disconnetti</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Benvenuto nella console RPC di %1.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Usa le frecce direzionali per scorrere la cronologia, e &lt;b&gt;Ctrl-L&lt;/b&gt; per cancellarla.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Scrivi &lt;b&gt;help&lt;/b&gt; per un riassunto dei comandi disponibili.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(id nodo: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>via %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>mai</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>In entrata</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>In uscita</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>Connected peers</source>
        <translation>Peers collegati</translation>
    </message>
    <message>
        <source>Add new peer</source>
        <translation>Aggiungi peer</translation>
    </message>
    <message>
        <source>Remove peer</source>
        <translation>Rimuovi peer</translation>
    </message>
    <message>
        <source>One try peer</source>
        <translation>Peer con tentativo singolo di connessione</translation>
    </message>
    <message>
        <source>Min Ping</source>
        <translation>Ping Minimo</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation>Banna per</translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation>Rimuovi ban</translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramification of a command.</source>
        <translation>ATTENZIONE: Truffatori potrebbero tentare di convincere utenti inesperti ad utilizzare comandi che permettono di rubare il contenuto del loro portafoglio. Non usare questa console se non conosci alla perfezione il rischio che comporta l&apos;utilizzo di ciascun comando.</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation>Attività di rete disabilitata</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <source>Remove Peer</source>
        <translation>Rimuovi Peer</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the peer: </source>
        <translation>Sei sicuro di volere rimuovere il peer?: </translation>
    </message>
    <message>
        <source>No peer was selected.</source>
        <translation>Nessun peer selezionato.</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Importo:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etichetta:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Messaggio:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Riutilizza uno degli indirizzi di ricezione generati in precedenza. Riutilizzare un indirizzo comporta problemi di sicurezza e privacy. Non selezionare questa opzione a meno che non si stia rigenerando una richiesta di pagamento creata in precedenza.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>R&amp;iusa un indirizzo di ricezione (non raccomandato)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Dogecoin network.</source>
        <translation>Un messaggio opzionale da allegare alla richiesta di pagamento, il quale sarà mostrato all&apos;apertura della richiesta. Nota: Il messaggio non sarà inviato con il pagamento sulla rete Dogecoin.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Un&apos;etichetta opzionale da associare al nuovo indirizzo di ricezione.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Usa questo modulo per richiedere pagamenti. Tutti i campi sono &lt;b&gt;opzionali&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Un importo opzionale da associare alla richiesta. Lasciare vuoto o a zero per non richiedere un importo specifico.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Cancellare tutti i campi del modulo.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Cronologia pagamenti richiesti</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Richiedi pagamento</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Mostra la richiesta selezionata (produce lo stesso effetto di un doppio click su una voce)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Mostra</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Rimuovi le voci selezionate dalla lista</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>Copia URI</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia etichetta</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Copia il messaggio</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>Codice QR</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Copia &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Copia &amp;Indirizzo</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Salva Immagine...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Richiesta di pagamento a %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Informazioni di pagamento</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>L&apos;URI generato è troppo lungo. Riduci la lunghezza del testo.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Errore nella codifica dell&apos;URI nel codice QR.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(nessun messaggio)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation>(nessun importo richiesto)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation>Richiesto</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Invia Dogecoin</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Funzionalità di Coin Control</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Input...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>selezionato automaticamente</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Fondi insufficienti!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantità:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Importo:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Commissione:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Dopo Commissione:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Resto:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>In caso di abilitazione con indirizzo vuoto o non valido, il resto sarà inviato ad un nuovo indirizzo generato appositamente.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Personalizza indirizzo di resto</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Commissione di Transazione:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Scegli...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>minimizza le impostazioni di commissione</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>per kilobyte</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Nascondi</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>somma almeno</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for dogecoin transactions than the network can process.</source>
        <translation>Pagare la commissione minima dovrebbe essere sufficiente, a patto che il volume delle transazioni sia inferiore allo spazio disponibile nei blocchi. Occorre comunque essere consapevoli che ciò potrebbe impedire la conferma delle transazioni nel caso in cui la rete risultasse satura.</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(leggi il suggerimento)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Raccomandata:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Personalizzata:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Invia simultaneamente a più beneficiari</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>&amp;Aggiungi beneficiario</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Cancellare tutti i campi del modulo.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Polvere (dust):</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Cancella &amp;tutto</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Conferma l&apos;azione di invio</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Invia</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Copia quantità</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Copia commissione</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Copia dopo commissione</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Copia byte</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Copia polvere (dust)</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Copia resto</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 a %2</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation> Includi il costo della transazione</translation>
    </message>
    <message>
        <source>or</source>
        <translation>o</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Saldo insufficiente</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Creazione della transazione fallita!</translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation>La transazione è stata respinta per il seguente motivo: %1</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Richiesta di pagamento scaduta.</translation>
    </message>
    <message>
        <source>Warning: Invalid Dogecoin address</source>
        <translation>Attenzione: Indirizzo Dogecoin non valido</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Attenzione: Indirizzo per il resto sconosciuto</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation>Attenzione: Non è possibile calcolare le commissioni di transazione in questo momento.</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 satoshis in fee, while &quot;total at least&quot; pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Se la commissioni di transazione sono configurate su 1000 satoshi e la transazione è solo 250 bytes, la commissione sarà solamente di 250 satoshi per kilobyte, mentre il totale sarà di almeno 1000 satoshi. Per transazioni più grandi di un kilobyte entrambi pagano per kilobyte.</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <source>low</source>
        <translation>bassa</translation>
    </message>
    <message>
        <source>high</source>
        <translation>alta</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Sei sicuro di voler inviare?</translation>
    </message>
    <message>
        <source>Total Amount %1</source>
        <translation>Importo Totale %1</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Conferma invio</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation>L&apos;indirizzo del destinatario non è valido, controlla di nuovo.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>L&apos;importo da inviare deve essere superiore a 0.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Il totale, inclusa la commissione di transazione di %1, è superiore al saldo disponibile.</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation>Indirizzo già inserito: non puoi riutilizzare lo stesso indirizzo.</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation>Commissioni di transazione superiori a %1 sono irragionevolmente alte.</translation>
    </message>
    <message>
        <source>Pay only the required fee of %1</source>
        <translation>Paga solo le commissioni di transazione richieste di %1</translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation>Conferma l&apos;indirizzo di scambio</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation>L&apos;indirizzo che hai selezionato come indirizzo di scambio non appartiene a questo portafoglio. I tuoi fondi potrebbero essere totalmente o in parte inviati a questo indirizzo. Sei sicuro?</translation>
    </message>
    <message>
        <source>Using the fallbackfee can result in sending a transaction that will take several hours or days (or never) to confirm. Consider choosing your fee manually or wait until you have validated the complete chain.</source>
        <translation>L&apos;utilizzo del fallbackfee (commissione di transazione di riserva) può causare l&apos;invio di transazioni che impiegano ore o giorni prima di essere confermate. Considera la possibilitá di scegliere le commissioni di transazione manualmente o di attendere che l&apos;intera chain sia stata convalidata.</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 koinu and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 koinu in fee, while &quot;total at least&quot; pays 1000 koinu. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Se la commissione di transazione è impostata su 1000 koinu e la transazione è solo 250 bytes, la commissione sarà solamente di 250 koinu per kilobyte, mentre il totale sarà di almeno 1000 koinu. Per transazioni più grandi di un kilobyte entrambi pagano per kilobyte.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Importo:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Paga &amp;a:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etichetta:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Scegli un indirizzo usato precedentemente</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Questo è un normale pagamento.</translation>
    </message>
    <message>
        <source>The Dogecoin address to send the payment to</source>
        <translation>L&apos;indirizzo Dogecoin a cui vuoi inviare il pagamento</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Incollare l&apos;indirizzo dagli appunti</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Rimuovi questa voce</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less dogecoins than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>La commissione sarà sottratta dall&apos;importo che si sta inviando. Il beneficiario riceverà un totale di dogecoin inferiore al valore inserito. Nel caso in cui siano stati selezionati più beneficiari la commissione sarà divisa in parti uguali.</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>S&amp;ottrae la commissione dall&apos;importo</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Messaggio:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>Questa è una richiesta di pagamento non autenticata.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>Questa è una richiesta di pagamento autenticata.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Inserisci un&apos;etichetta per questo indirizzo per aggiungerlo alla lista degli indirizzi utilizzati</translation>
    </message>
    <message>
        <source>A message that was attached to the dogecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Dogecoin network.</source>
        <translation>Messaggio incluso nell&apos;URI dogecoin e che sarà memorizzato con la transazione. Nota: questo messaggio non sarà inviato attraverso la rete Dogecoin.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Pagare a:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Inserisci un&apos;etichetta per questo indirizzo per aggiungerlo alla tua rubrica</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>Arresto di %1 in corso...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Non spegnere il computer fino a quando questa finestra non si sarà chiusa.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Firme - Firma / Verifica un messaggio</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Firma Messaggio</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive dogecoins sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Puoi firmare messaggi/accordi con i tuoi indirizzi per dimostrare di poterli utilizzare per ricevere Dogecoin. Si consiglia di fare attenzione a non firmare dichiarazioni vaghe o casuali che potrebbero essere utilizzate in attacchi phishing. Si raccomanda di firmare esclusivamente dichiarazioni dettagliate e delle quali si condivide in pieno il contenuto.</translation>
    </message>
    <message>
        <source>The Dogecoin address to sign the message with</source>
        <translation>L&apos;indirizzo Dogecoin da utilizzare per firmare il messaggio</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Scegli un indirizzo usato precedentemente</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Incolla l&apos;indirizzo dagli appunti</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Inserisci qui il messaggio che vuoi firmare</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copia la firma corrente nella clipboard</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Dogecoin address</source>
        <translation>Firma un messaggio per dimostrare di possedere questo indirizzo</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Firma &amp;Messaggio</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Reimposta tutti i campi della firma messaggio</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Cancella &amp;Tutto</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifica Messaggio</translation>
    </message>
    <message>
        <source>Enter the receiver&apos;s address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>Per verificare il messaggio inserire l&apos;indirizzo del firmatario, il messaggio e la firma nei campi sottostanti, assicurandosi di copiare esattamente anche ritorni a capo, spazi, tabulazioni, etc. Si raccomanda di non lasciarsi fuorviare dalla firma a leggere più di quanto non sia riportato nel testo del messaggio stesso, in modo da evitare di cadere vittima di attacchi di tipo man-in-the-middle. Si ricorda che la verifica della firma dimostra soltanto che il firmatario può ricevere pagamenti con l&apos;indirizzo corrispondente, non prova l&apos;invio di alcuna transazione.</translation>
    </message>
    <message>
        <source>The Dogecoin address the message was signed with</source>
        <translation>L&apos;indirizzo Dogecoin con cui è stato firmato il messaggio</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Dogecoin address</source>
        <translation>Verifica il messaggio per accertare che sia stato firmato con l&apos;indirizzo specificato</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verifica &amp;Messaggio</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Reimposta tutti i campi della verifica messaggio</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>L&apos;indirizzo inserito non è valido.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Per favore controlla l&apos;indirizzo e prova di nuovo.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>L&apos;indirizzo inserito non è associato a nessuna chiave.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Sblocco del portafoglio annullato.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>La chiave privata per l&apos;indirizzo inserito non è disponibile.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Firma messaggio fallita.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Messaggio firmato.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Non è stato possibile decodificare la firma.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Per favore, controlla la firma e prova di nuovo.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>La firma non corrisponde al digest del messaggio.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verifica messaggio fallita.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Messaggio verificato.</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Clicca &quot;Firma Messaggio&quot; per generare una firma.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TestPeerDialog</name>
    <message>
        <source>Test Peer</source>
        <translation>Testa il Peer</translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation>Inserisci i dettagli del peer.</translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation>Fai attenzione! Non fidarti ciecamente di chi ti chiede di aggiungere il suo nodo.</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation>Aggiungi l&apos;indirizzo del peer</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation>Aggiungi la porta del peer</translation>
    </message>
    <message>
        <source>Test!</source>
        <translation>Inizia il test!</translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation>Inserisci un indirizzo.</translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation>Inserisci un indirizzo valido per il peer.</translation>
    </message>
    <message>
        <source>Try Peer</source>
        <translation>Prova il Peer</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>0/unconfirmed, %1</source>
        <translation>0/non confermati, %1</translation>
    </message>
    <message>
        <source>abandoned</source>
        <translation>abbandonato</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/non confermato</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 conferme</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Sorgente</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Generato</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>sconosciuto</translation>
    </message>
    <message>
        <source>To</source>
        <translation>A</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>proprio indirizzo</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>sola lettura</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etichetta</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Credito</translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>non accettate</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debito</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>Debito totale</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>Credito totale</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Commissione transazione</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Importo netto</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commento</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>ID della transazione</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Commerciante</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Informazione di debug</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transazione</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Input</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <source>true</source>
        <translation>vero</translation>
    </message>
    <message>
        <source>false</source>
        <translation>falso</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>Aperta per %n altro blocco</numerusform>
            <numerusform>Aperta per altri %n blocchi</numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Aperta fino a: %1</translation>
    </message>
    <message>
        <source>conflicted with a transaction with %1 confirmations</source>
        <translation>Incontrati conflitti con una transazione con %1 conferme</translation>
    </message>
    <message>
        <source>in memory pool</source>
        <translation>nella riserva di memoria</translation>
    </message>
    <message>
        <source>not in memory pool</source>
        <translation>non nella riserva di memoria</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>matura in %n blocco</numerusform>
            <numerusform>matura in %n blocchi</numerusform>
        </translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation>Dimensione totale della transazione</translation>
    </message>
    <message>
        <source>Output index</source>
        <translation>Indice di output</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>I dogecoin generati devono maturare ancora per %1 blocchi prima di essere spendibili. Dopo essere stato generato, questo blocco è stato trasmesso alla rete per essere aggiunto alla blockchain. Se l&apos;inserimento nella blockchain dovesse fallire, il suo stato cambierà a &quot;non accettato&quot; e i dogecoin non saranno spendibili. Alle volte, questo può accadere nel caso in cui un altro nodo generi un blocco entro pochi secondi dal tuo.</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Questo pannello mostra una descrizione dettagliata della transazione</translation>
    </message>
    <message>
        <source>Details for %1</source>
        <translation>Dettagli per %1</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Non confermata</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confermata (%1 conferme)</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Generati, ma non accettati</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Ricevuto tramite</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Inviato a</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Pagamento a te stesso</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Ottenuto dal mining</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>sola lettura</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/d)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Stato della transazione. Passare con il mouse su questo campo per visualizzare il numero di conferme.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Data e ora in cui la transazione è stata ricevuta.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Tipo di transazione.</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>Indica se un indirizzo di sola lettura sia o meno coinvolto in questa transazione.</translation>
    </message>
    <message>
        <source>User-defined intent/purpose of the transaction.</source>
        <translation>Intento/scopo della transazione definito dall&apos;utente.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Importo rimosso o aggiunto al saldo.</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>Aperta per %n altro blocco</numerusform>
            <numerusform>Aperta per altri %n blocchi</numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Aperta fino a: %1</translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation>Abbandonata</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>In conferma (%1 su %2 conferme raccomandate)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>In conflitto</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Immatura (%1 conferme totali, disponibile fra %2)</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Ricevuta da</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Oggi</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Questa settimana</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Questo mese</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Il mese scorso</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Quest&apos;anno</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Intervallo...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Ricevuto tramite</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Inviato a</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>A te stesso</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Ottenuto dal mining</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Altro</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Inserisci un indirizzo o un&apos;etichetta da cercare</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Importo minimo</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copia indirizzo</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia etichetta</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Copia l&apos;ID transazione</translation>
    </message>
    <message>
        <source>Copy raw transaction</source>
        <translation>Copia la transazione raw</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Modifica l&apos;etichetta</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Mostra i dettagli della transazione</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Esporta lo storico delle transazioni</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>Sola lettura</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Esportazione Fallita</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>Si è verificato un errore durante il salvataggio dello storico delle transazioni in %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Esportazione Riuscita</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Lo storico delle transazioni e&apos; stato salvato con successo in %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Intervallo:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <source>Abandon transaction</source>
        <translation>Abbandona transazione</translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation>Copia tutti i dettagli della transazione</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Unità con cui visualizzare gli importi. Clicca per selezionare un&apos;altra unità.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Non è stato caricato alcun portafoglio.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Invia Dogecoin</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Esporta</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Esporta su file i dati contenuti nella tabella corrente</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Backup Portafoglio</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Dati Portafoglio (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Backup Fallito</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Si è verificato un errore durante il salvataggio dei dati del portafoglio in %1.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Backup eseguito con successo</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Il portafoglio è stato correttamente salvato in %1.</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Opzioni:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Specifica la cartella dati</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Connessione ad un nodo e successiva disconnessione per recuperare gli indirizzi dei peer</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Specifica il tuo indirizzo pubblico</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accetta comandi da riga di comando e JSON-RPC</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</source>
        <translation>Se &lt;category&gt; non è specificato oppure se &lt;category&gt; = 1, mostra tutte le informazioni di debug.</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>La modalità pruned è configurata al di sotto del minimo di %d MB. Si prega di utilizzare un valore più elevato.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>L&apos;ultima sincronizzazione del wallet va oltre il limite specificato per la modalità pruned. È necessario utilizzare l&apos;opzione -reindex e scaricare nuovamente la blockchain.</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>Non è possibile un rescan in modalità pruned. È necessario utilizzare l&apos;opzione -reindex per scaricare nuovamente tutta la blockchain.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Errore: si è presentato un errore irreversibile, consulta il file debug.log per maggiori dettagli</translation>
    </message>
    <message>
        <source>Fee (in %s/kB) to add to transactions you send (default: %s)</source>
        <translation>Commissione (in %s/kB) da aggiungere alle transazioni inviate (default: %s)</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>Pruning del blockstore...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Esegui in background come demone ed accetta i comandi</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>Impossibile avviare il server HTTP. Dettagli nel log di debug.</translation>
    </message>
    <message>
        <source>Dogecoin Core</source>
        <translation>Dogecoin Core</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>Sviluppatori di %s</translation>
    </message>
    <message>
        <source>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</source>
        <translation>Un importo (in %s/kB) che sarà utilizzato quando la stima delle commissioni non ha abbastanza dati (default: %s)</translation>
    </message>
    <message>
        <source>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</source>
        <translation>Accetta le transazioni trasmesse ricevute da peers in whitelist anche se non si stanno trasmettendo transazioni (default: %d)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Associa all&apos;indirizzo indicato e resta permanentemente in ascolto su di esso. Usa la notazione [host]:porta per l&apos;IPv6</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>Non è possibile ottenere i dati sulla cartella %s. Probabilmente %s è già in esecuzione.</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Elimina tutte le transazioni dal portafoglio e recupera solo quelle che fanno parte della blockchain usando il comando -rescan all&apos;avvio</translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t enable HD on a already existing non-HD wallet</source>
        <translation>Errore caricamento %s: Non puoi abilitare HD in un portafoglio non-HD già esistente</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Errore lettura %s! Tutte le chiavi sono state lette correttamente, ma i dati delle transazioni o della rubrica potrebbero essere mancanti o non corretti.</translation>
    </message>
    <message>
        <source>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</source>
        <translation>Regolazione della massima differenza media di tempo dei peer consentita. L&apos;impostazione dell&apos;orario locale può essere modificata in avanti o indietro di questa quantità. (default %u secondi)</translation>
    </message>
    <message>
        <source>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</source>
        <translation>Totale massimo di commissioni (in %s) da usare in una transazione singola o di gruppo del wallet; valori troppo bassi possono abortire grandi transazioni (default: %s)</translation>
    </message>
    <message>
        <source>Please check that your computer&apos;s date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>Per favore controllate che la data del computer e l&apos;ora siano corrette! Se il vostro orologio è sbagliato %s non funzionerà correttamente.</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation>Per favore, contribuisci se ritieni %s utile. Visita %s per maggiori informazioni riguardo il software.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Imposta il numero di thread per la verifica degli script (da %u a %d, 0 = automatico, &lt;0 = lascia questo numero di core liberi, predefinito: %d)</translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer&apos;s date and time being set incorrectly. Only rebuild the block database if you are sure that your computer&apos;s date and time are correct</source>
        <translation>Il database dei blocchi contiene un blocco che sembra provenire dal futuro. Questo può essere dovuto alla data e ora del tuo computer impostate in modo scorretto. Ricostruisci il database dei blocchi se sei certo che la data e l&apos;ora sul tuo computer siano corrette</translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation>Impossibile riportare il database ad un livello pre-fork. Dovrai riscaricare tutta la blockchain</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</source>
        <translation>Utilizza UPnP per mappare la porta in ascolto (default: 1 quando in ascolto e -proxy non è specificato)</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex-chainstate to change -txindex</source>
        <translation>È necessario ricostruire il database usando -reindex per cambiare -txindex</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>%s corrotto, recupero fallito</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>-maxmempool deve essere almeno %d MB</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>Valori possibili per &lt;category&gt;:</translation>
    </message>
    <message>
        <source>Append comment to the user agent string</source>
        <translation>Aggiungi commento alla stringa dell&apos;applicazione utente</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet on startup</source>
        <translation>Prova a recuperare le chiavi private da un portafoglio corrotto all&apos;avvio</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Opzioni creazione blocco:</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: &apos;%s&apos;</source>
        <translation>Impossobile risolvere l&apos;indirizzo -%s: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Change index out of range</source>
        <translation>Cambio indice fuori paramentro</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Opzioni di connessione:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Copyright (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Rilevato database blocchi corrotto</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Opzioni di Debug/Test:</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Disabilita il portafoglio e le relative chiamate RPC</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Vuoi ricostruire ora il database dei blocchi?</translation>
    </message>
    <message>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation>Abilita pubblicazione hash blocco in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation>Abilità pubblicazione hash transazione in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation>Abilita pubblicazione blocchi raw in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation>Abilita pubblicazione transazione raw in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable transaction replacement in the memory pool (default: %u)</source>
        <translation>Abilita la sostituzione della transazione nel pool della memoria (default: %u)</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Errore durante l&apos;inizializzazione del database dei blocchi</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Errore durante l&apos;inizializzazione dell&apos;ambiente del database del portafoglio %s!</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Errore caricamento %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Errore caricamento %s: Portafoglio corrotto</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Errore caricamento %s: il Portafoglio richiede una versione aggiornata di %s</translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t disable HD on a already existing HD wallet</source>
        <translation>Errore caricamento %s: Non puoi disabilitare HD in un portafoglio HD già esistente</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Errore durante il caricamento del database blocchi</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Errore durante l&apos;apertura del database blocchi</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Errore: la spazio libero sul disco è insufficiente!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Nessuna porta disponibile per l&apos;ascolto. Usa -listen=0 se vuoi procedere comunque.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importazione...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Blocco genesi non corretto o non trovato. È possibile che la cartella dati appartenga ad un&apos;altra rete.</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>Test di integrità iniziale fallito. %s si arresterà.</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>Indirizzo -onion non valido: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Importo non valido per -%s=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Importo non valido per -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</source>
        <translation>Mantieni la memory pool delle transazioni al di sotto di &lt;n&gt; megabytes (default: %u)</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>Caricamento bloccati...</translation>
    </message>
    <message>
        <source>Location of the auth cookie (default: data dir)</source>
        <translation>Posizione del cookie di aiutorizzazione (default: data dir)</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Non ci sono abbastanza descrittori di file disponibili.</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Connessione ai soli nodi appartenenti alla rete &lt;net&gt; (ipv4, ipv6 o Tor)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>Mostra questo messaggio di aiuto ed esci</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>Mostra la versione ed esci</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>La modalità prune non può essere configurata con un valore negativo.</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>La modalità prune è incompatibile con l&apos;opzione -txindex.</translation>
    </message>
    <message>
        <source>Rebuild chain state and block index from the blk*.dat files on disk</source>
        <translation>Ricostruisci lo stato della catena e l&apos;indice dei blocchi partendo dai file blk*.dat presenti sul disco</translation>
    </message>
    <message>
        <source>Rebuild chain state from the currently indexed blocks</source>
        <translation>Ricrea l&apos;indice della catena dei blocchi partendo da quelli già indicizzati</translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation>Verifica blocchi...</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Imposta la dimensione della cache del database in megabyte (%d a %d, predefinito: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Imposta la dimensione massima del blocco in byte (predefinito: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Specifica il file del portafoglio (all&apos;interno della cartella dati)</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>Il codice sorgente è disponibile qui: %s</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>Impossibile collegarsi a %s su questo computer. Probabilmente %s è già in esecuzione.</translation>
    </message>
    <message>
        <source>Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Ignorata opzione -benchmark non supportata, utilizzare -debug=bench.</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Argomento -debugnet ignorato in quanto non supportato, usare -debug=net.</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>Rilevato argomento -tor non supportato, utilizzare -onion.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>Usa UPnP per mappare la porta di ascolto (predefinito: %u)</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation>Il commento del User Agent (%s) contiene caratteri non sicuri.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verifica blocchi...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verifica portafoglio...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Il portafoglio %s si trova al di fuori dalla cartella dati %s</translation>
    </message>
    <message>
        <source>Wallet debugging/testing options:</source>
        <translation>Opzioni di Debug/Test del portafoglio:</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Il portafoglio necessita di essere riscritto: riavviare %s per completare</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Opzioni portafoglio:</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>Permette connessioni JSON-RPC dall&apos;origine specificata. I valori validi per &lt;ip&gt; sono un singolo IP (ad es. 1.2.3.4), una network/netmask (ad es. 1.2.3.4/255.255.255.0) oppure una network/CIDR (ad es. 1.2.3.4/24). Questa opzione può essere specificata più volte.</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>Resta in ascolto sull&apos;indirizzo indicato ed inserisce in whitelist i peer che vi si collegano. Usa la notazione [host]:porta per l&apos;IPv6</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>Resta in attesa di connessioni JSON-RPC sull&apos;indirizzo indicato. Usa la notazione [host]:porta per IPv6. Questa opzione può essere specificata più volte (predefinito: associa a tutte le interfacce) </translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Crea nuovi file con i permessi di default del sistema, invece che con umask 077 (ha effetto solo con funzionalità di portafoglio disabilitate)</translation>
    </message>
    <message>
        <source>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</source>
        <translation>Scopre i propri indirizzi IP (predefinito: 1 se in ascolto ed -externalip o -proxy non sono specificati)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Errore: attesa per connessioni in arrivo fallita (errore riportato %s)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</source>
        <translation>Le commissioni (in %s/kB) inferiori a questo valore sono considerate pari a zero per trasmissione, mining e creazione della transazione (default: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>Nel caso in cui paytxfee non sia impostato, include una commissione tale da ottenere un avvio delle conferme entro una media di n blocchi (predefinito: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Importo non valido per -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (deve essere almeno pari alla commissione &apos;minrelay fee&apos; di %s per prevenire transazioni bloccate)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Dimensione massima dei dati in transazioni di trasporto dati che saranno trasmesse ed incluse nei blocchi (predefinito: %u)</translation>
    </message>
    <message>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation>Randomizza le credenziali per ogni connessione proxy. Permette la Tor stream isolation (predefinito: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Imposta la dimensione massima in byte delle transazioni ad alta-priorità/basse-commissioni (predefinito: %d)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>L&apos;importo della transazione risulta troppo basso per l&apos;invio una volta dedotte le commissioni.</translation>
    </message>
    <message>
        <source>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</source>
        <translation>Usa la generazione gerarchica deterministica (HD) della chiave dopo BIP32. Valido solamente durante la creazione del portafoglio o al primo avvio</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>I peer inclusi in whitelist non possono subire ban per DoS e le loro transazioni saranno sempre trasmesse, anche nel caso in cui si trovino già nel mempool. Ciò è utile ad es. per i gateway</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation>Per ritornare alla modalità unpruned sarà necessario ricostruire il database utilizzando l&apos;opzione -reindex. L&apos;intera blockchain sarà riscaricata.</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(default: %u)</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Accetta richieste REST pubbliche (predefinito: %u)</translation>
    </message>
    <message>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation>Crea automaticamente il servizio Tor (default: %d)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Connessione attraverso un proxy SOCKS5</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Errore durante la lettura del database. Arresto in corso.</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file on startup</source>
        <translation>Importa blocchi da un file blk000??.dat esterno all&apos;avvio</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least %s)</source>
        <translation>Importo non valido per -paytxfee=&lt;amount&gt;: &apos;%s&apos; (deve essere almeno %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: &apos;%s&apos;</source>
        <translation>Netmask non valida specificata in -whitelist: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Mantiene in memoria al massimo &lt;n&gt; transazioni non collegabili (predefinito: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: &apos;%s&apos;</source>
        <translation>È necessario specificare una porta con -whitebind: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Opzioni trasmissione nodo:</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>Opzioni server RPC:</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>Riduzione -maxconnections da %d a %d a causa di limitazioni di sistema.</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions on startup</source>
        <translation>Ripete la scansione della blockchain per individuare le transazioni che mancano dal wallet all&apos;avvio</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Invia le informazioni di trace/debug alla console invece che al file debug.log</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Invia transazioni a zero commissioni se possibile (predefinito: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Mostra tutte le opzioni di debug (utilizzo: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Riduce il file debug.log all&apos;avvio del client (predefinito: 1 se -debug non è impostato)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Firma transazione fallita</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>L&apos;importo della transazione è troppo basso per pagare la commissione</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Questo è un software sperimentale.</translation>
    </message>
    <message>
        <source>Tor control port password (default: empty)</source>
        <translation>Password porta controllo Tor (default: empty)</translation>
    </message>
    <message>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation>Porta di controllo Tor da usare se in ascolto su onion (default: %s)</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Importo transazione troppo piccolo</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transazione troppo grande in base alla policy sulle commissioni</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transazione troppo grande</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Impossibile associarsi a %s su questo computer (l&apos;associazione ha restituito l&apos;errore %s)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format on startup</source>
        <translation>Aggiorna il wallet all&apos;ultimo formato all&apos;avvio</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Nome utente per connessioni JSON-RPC</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation>Attenzione: nuove regole non conosciute attivate (versionbit %i)</translation>
    </message>
    <message>
        <source>Whether to operate in a blocks only mode (default: %u)</source>
        <translation>Imposta se operare in modalità solo blocchi (default: %u)</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Eliminazione dal portafoglio di tutte le transazioni...</translation>
    </message>
    <message>
        <source>ZeroMQ notification options:</source>
        <translation>Opzioni di notifica ZeroMQ</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Password per connessioni JSON-RPC</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Consente interrogazioni DNS per -addnode, -seednode e -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Caricamento indirizzi...</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = mantiene metadati tx, ad es. proprietario account ed informazioni di richiesta di pagamento, 2 = scarta metadati tx)</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>-maxtxfee è impostato molto alto! Commissioni così alte possono venir pagate anche su una singola transazione.</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>Non mantenere le transazioni nella mempool più a lungo di &lt;n&gt; ore (default: %u)</translation>
    </message>
    <message>
        <source>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</source>
        <translation>Byte equivalenti per ottimizzazione segnale dedicati a ritrasmissione ed estrazione (default: %u)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Le commissioni (in %s/kB) inferiori a questo valore sono considerate pari a zero per la creazione della transazione (default: %s)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>Determina quanto sarà approfondita la verifica da parte di -checkblocks (0-4, predefinito: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Mantiene l&apos;indice completo delle transazioni usato dalla chiamata rpc getrawtransaction (predefinito: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Numero di secondi di sospensione prima della riconnessione per i peer che mostrano un comportamento anomalo (predefinito: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Emette informazioni di debug (predefinito: %u, fornire &lt;category&gt; è opzionale)</translation>
    </message>
    <message>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation>Supporta filtraggio di blocchi e transazioni con filtri bloom (default: %u)</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation>La lunghezza totale della stringa di network version (%i) eccede la lunghezza massima (%i). Ridurre il numero o la dimensione di uacomments.</translation>
    </message>
    <message>
        <source>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</source>
        <translation>Cerca di mantenere il traffico in uscita al di sotto della soglia scelta (in MiB ogni 24h), 0 = nessun limite (default: %d)</translation>
    </message>
    <message>
        <source>Unsupported argument -socks found. Setting SOCKS version isn&apos;t possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Argomento -socks non supportato. Non è più possibile impostare la versione SOCKS, solamente i proxy SOCKS5 sono supportati.</translation>
    </message>
    <message>
        <source>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</source>
        <translation>Argomento non supportato -whitelistalwaysrelay è stato ignorato, utilizzare -whitelistrelay e/o -whitelistforcerelay.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Usa un proxy SOCKS5 a parte per raggiungere i peer attraverso gli hidden services di Tor (predefinito: %s)</translation>
    </message>
    <message>
        <source>Warning: Unknown block versions being mined! It&apos;s possible unknown rules are in effect</source>
        <translation>Attenzione: si stanno minando versioni sconocsiute di blocchi! E&apos; possibile che siano attive regole sconosciute</translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Attenzione: file del Portafoglio corrotto, dati recuperati! %s originale salvato come %s in %s; se il saldo o le transazioni non sono corrette effettua un ripristino da un backup.</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(predefinito: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Interroga sempre i DNS per ottenere gli indirizzi dei peer (predefinito: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>Numero di blocchi da controllare all&apos;avvio (predefinito: %u, 0 = tutti)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>Include gli indirizzi IP nell&apos;output del debug (predefinito: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Indirizzo -proxy non valido: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Resta in attesa di connessioni JSON-RPC su &lt;port&gt; (predefinito: %u o testnet: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Resta in attesa di connessioni su &lt;port&gt; (predefinito: %u o testnet: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Mantiene al massimo &lt;n&gt; connessioni verso i peer (predefinito: %u)</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>Configura il portafoglio per la trasmissione di transazioni</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Buffer di ricezione massimo per connessione, &lt;n&gt;*1000 byte (predefinito: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Buffer di invio massimo per connessione, &lt;n&gt;*1000 byte (predefinito: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Antepone un timestamp all&apos;output del debug (predefinito: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>Trasmette ed include nei blocchi transazioni di trasporto dati (predefinito: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Trasmette transazioni non-P2SH multisig (predefinito: %u)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Imposta la dimensione del pool di chiavi a &lt;n&gt; (predefinito: %u)</translation>
    </message>
    <message>
        <source>Set maximum BIP141 block weight (default: %d)</source>
        <translation>Imposta la dimensione massima del blocco BIP141 (default: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Imposta il numero di thread destinati a rispondere alle chiamate RPC (predefinito %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Specifica il file di configurazione (predefinito: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Specifica il timeout di connessione in millisecondi (minimo:1, predefinito: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>Specifica il file pid (predefinito: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Abilita la spesa di resto non confermato quando si inviano transazioni (predefinito: %u)</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Soglia di disconnessione per i peer che si comportano in maniera anomala (predefinito: %u)</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Rete sconosciuta specificata in -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Fondi insufficienti</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Caricamento dell&apos;indice dei blocchi...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Aggiunge un nodo a cui connettersi e tenta di mantenere aperta la connessione</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Caricamento portafoglio...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Non è possibile effettuare il downgrade del portafoglio</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Non è possibile scrivere l&apos;indirizzo predefinito</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Ripetizione scansione...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Caricamento completato</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <source>Bitcoin Core and Dogecoin Core</source>
        <translation>Bitcoin Core e Dogecoin Core</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect/-noconnect)</source>
        <translation>Accetta connessioni esterne (default: 1 se le opzioni -proxy e -connect/-noconnect non sono specificate)</translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered dust, in %s (default: %s)</source>
        <translation>Valore minimo sotto il quale l&apos;output di una transazione deve essere considerato polvere (dust), in %s (default: %s)</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s); -noconnect or -connect=0 alone to disable automatic connections</source>
        <translation>Connettiti solo con i nodi specificati; usa -noconnect o -connect=0 per disabilitare le connessioni automatiche.</translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file %s or %s</source>
        <translation>Distribuito ai sensi della licenza software MIT. Per informazioni leggere il file %s o la pagina %s</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash, %i is replaced by block number)</source>
        <translation>Esegui il comando quando l&apos;ultimo miglior blocco cambia (%s nel comando verrá sostituito con l&apos;hash del blocco, %i verrá sostituito con il numero del blocco)</translation>
    </message>
    <message>
        <source>Extra transactions to keep in memory for compact block reconstructions (default: %u)</source>
        <translation>Transazioni aggiuntive da tenere in memoria per la ricostruzione dei blocchi (default: %u)</translation>
    </message>
    <message>
        <source>Force relay of transactions from whitelisted peers even if they violate local relay policy (default: %d)</source>
        <translation>Trasmetti le transazioni inviate dai peers nella whitelist anche se violano le regole di relay locali (default: %d)</translation>
    </message>
    <message>
        <source>If this block is in the chain assume that it and its ancestors are valid and potentially skip their script verification (0 to verify all, default: %s, testnet: %s)</source>
        <translation>Se giá incluso nella blockchain, considera questo blocco e i blocchi antecedenti validi e ometti la verifica degli script (0 per verificare tutti i blocchi, default: %s, testnet: %s)</translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect/-noconnect)</source>
        <translation>Richiedi indirizzi peers tramite lookup DNS, se sono disponibili solo pochi peers (default: 1 nel caso in cui le opzioni -connect/-noconnect non siano specificate)</translation>
    </message>
    <message>
        <source>Reduce storage requirements by enabling pruning (deleting) of old blocks. This allows the pruneblockchain RPC to be called to delete specific blocks, and enables automatic pruning of old blocks if a target size in MiB is provided. This mode is incompatible with -txindex and -rescan. Warning: Reverting this setting requires re-downloading the entire blockchain. (default: 0 = disable pruning blocks, 1 = allow manual pruning via RPC, &gt;%u = automatically prune block files to stay under the specified target size in MiB)</source>
        <translation>Riduci lo spazio occupato su disco abilitando la cancellazione (pruning) dei blocchi più vecchi. Questo permette l&apos;utilizzazione del comando RPC pruneblockchain per cancellare blocchi specifici, e abilita la cancellazione automatica dei blocchi più vecchi se viene specificato un target massimo per lo spazio occupato su disco in MiB. Questa modalitá è incompatibile con -txindex e -rescan. Attenzione: la modifica di questa opzione richiede una nuova sincronizzazione dell&apos;intera blockchain con la rete. (default: 0 = disabilita cancellazione dei blocchi, 1 = abilita cancellazione dei blocchi via RPC, &gt;%u = cancella automaticamente i file dei blocchi per rimanere al di sotto del target massimo specificato in MiB)</translation>
    </message>
    <message>
        <source>Set lowest fee rate (in %s/kB) for transactions to be included in block creation. (default: %s)</source>
        <translation>Inserisci la commissione minima (in %s/kB) per l&apos;inclusione delle transazioni nei blocchi. (default: %s)</translation>
    </message>
    <message>
        <source>Sets the serialization of raw transaction or block hex returned in non-verbose mode, non-segwit(0) or segwit(1) (default: %d)</source>
        <translation>Imposta la serializzazione delle transazioni raw e dei blocchi esadecimali in modalitá non-verbosa, non-segwit (0) o segwit (1) (default: %d)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Il presente software è una versione preliminare - ogni uso è a proprio rischio e pericolo. Non utilizzare per il mining o per applicazioni a scopo commerciale</translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation>Questa è la commissione di transazione utilizzata quando il calcolo automatico delle commissioni non è disponibile.</translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit %s and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard. Paper wallet art provided by Anacoluthia.</source>
        <translation>Questo prodotto include software sviluppato dall&apos;OpenSSL Project per l&apos;utilizzazione nel Toolkit OpenSSL %s e in software crittografico creato da Eric Young e software UPnP creato da Tomas Bernard. Gli elementi grafici nei portafogli cartacei sono stati creati da Anacoluthia.</translation>
    </message>
    <message>
        <source>Username and hashed password for JSON-RPC connections. The field &lt;userpw&gt; comes in the format: &lt;USERNAME&gt;:&lt;SALT&gt;$&lt;HASH&gt;. A canonical python script is included in share/rpcuser. The client then connects normally using the rpcuser=&lt;USERNAME&gt;/rpcpassword=&lt;PASSWORD&gt; pair of arguments. This option can be specified multiple times</source>
        <translation>Il nome utente e l&apos;hash della password per connessioni JSON-RPC. Il campo &lt;userpw&gt; deve essere nel formato: &lt;NOMEUTENTE&gt;:&lt;SALT&gt;$&lt;HASH&gt;. Uno script python per la generazione del campo è incluso nella cartella share/rpcuser. Il client può successivamente connettersi normalmente utilizzando le opzioni rpcuser=&lt;NOMEUTENTE&gt;/rpcpassword=&lt;PASSWORD&gt;. L&apos;opzione può essere specificata varie volte.</translation>
    </message>
    <message>
        <source>Wallet will not create transactions that violate mempool chain limits (default: %u)</source>
        <translation>Il portafoglio eviterà di generare transazioni che violano i limiti della mempool chain (default: %u)</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Attenzione: La rete sembra essere in disaccordo! Pare che alcuni miner stiano riscontrando dei problemi.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Attenzione: Impossibile accordarsi con i peers! Potrebbe essere necessario aggiornare il software del tuo o degli altri nodi.</translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given IP address (e.g. 1.2.3.4) or CIDR notated network (e.g. 1.2.3.0/24). Can be specified multiple times.</source>
        <translation>Aggiungi i peers che si connettono da indirizzi IP predefiniti (e.g. 1.2.3.4) o da reti specificate in notazione CIDR (e.g. 1.2.3.0/24).</translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation>Il valore %s è molto alto!</translation>
    </message>
    <message>
        <source>Amaze</source>
        <translation>Fantastico</translation>
    </message>
    <message>
        <source>Chain selection options:</source>
        <translation>Seleziona una chain:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Default</translation>
    </message>
    <message>
        <source>Keypool ran out, please call keypoolrefill first</source>
        <translation>La keypool è vuota, usa keypoolrefill prima di continuare</translation>
    </message>
    <message>
        <source>Many generous</source>
        <translation>Molto generoso</translation>
    </message>
    <message>
        <source>Minimum</source>
        <translation>Minimo</translation>
    </message>
    <message>
        <source>More</source>
        <translation>Continua</translation>
    </message>
    <message>
        <source>Send transactions with full-RBF opt-in enabled (default: %u)</source>
        <translation>Invia transazioni che supportano l&apos;opzione di sostituzione con commissione (RBF) (default: %u)</translation>
    </message>
    <message>
        <source>Starting network threads...</source>
        <translation>Inizializzazione dei thread di rete...</translation>
    </message>
    <message>
        <source>Such expensive</source>
        <translation>Costosissimo!</translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation>Il portafoglio eviterá il pagamento di commissioni inferiori alle commissioni minime</translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation>Questa è la commissione minima da pagare per ogni transazione.</translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Questa è la commissione che pagherai quando invii una transazione.</translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation>Il totale della transazione non può essere negativo.</translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation>La transazione ha una mempool chain troppo lunga</translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation>La transazione deve avere almeno un destinatario</translation>
    </message>
    <message>
        <source>Use the test chain</source>
        <translation>Usa la test chain</translation>
    </message>
    <message>
        <source>Wow</source>
        <translation>Wow</translation>
    </message>
    <message>
        <source>-discardthreshold is set very high! This is the output amount that the wallet will discard (to fee) if it is smaller than this setting.</source>
        <translation>-discardthreshold è molto alto! Questo è il valore minimo di un output di transazione utilizzato per convalidare le transazioni del portafoglio e scartare il resto.</translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered non-standard and will not be accepted or relayed, in %s (default: %s)</source>
        <translation>Quantitá al di sotto della quale un output di transazione deve considerarsi non standard e quindi non accettato e non trasmesso, in %s (default: %s)</translation>
    </message>
    <message>
        <source>Invalid amount for -discardthreshold=&lt;amount&gt;: &apos;%s&apos; (must be at least the dust limit of %s to prevent stuck transactions)</source>
        <translation>Valore invalido per -discardthreshold=&lt;valore&gt;: &apos;%s&apos; (deve essere almeno uguale al limite di polvere %s per evitare il blocco involontario delle transazioni)</translation>
    </message>
    <message>
        <source>The minimum transaction output size (in %s) used to validate wallet transactions and discard change (to fee) (default: %s)</source>
        <translation>Il valore minimo di un output di transazione (in %s) utilizzato per convalidare le transazioni e scartare il resto (che verrá aggiunto alla commissione di transazione) (default: %s)</translation>
    </message>
    <message>
        <source>Use Namecoin-compatible AuxPow API structure, (default: %u)</source>
        <translation>Utilizza il formato API AuxPow compatibile con Namecoin, (default: %u)</translation>
    </message>
    <message>
        <source>Execute command when we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Esegui il comando quando viene rilevato un fork molto lungo (%s in cmd è sostituito dal messaggio)</translation>
    </message>
    <message>
        <source>Specify directory where to write backups and data dumps (default datadir/backups)</source>
        <translation>Specifica la cartella in cui salvare i backup e i dump di dati (default datadir/backups)</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID, %i with block height, with a value of 0 if tx is no longer in chaintip)</source>
        <translation>Esegui il comando quando viene rilevato un cambiamento in una transazione nel portafoglio (%s viene sostituito dal TxID, %i dal numero del blocco o con un valore 0 se la transazione non è più inclusa nella chaintip)</translation>
    </message>
    <message>
        <source>Enable BIP-70 PaymentServer (default: 0)</source>
        <translation>Abilita il server pagamenti BIP-70 (default: 0)</translation>
    </message>
</context>
</TS>
